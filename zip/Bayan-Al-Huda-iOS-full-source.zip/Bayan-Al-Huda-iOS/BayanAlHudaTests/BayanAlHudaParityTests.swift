import XCTest
@testable import BayanAlHuda

final class BayanAlHudaParityTests: XCTestCase {

    func testNooraniQaidaJSONHas53PagesAndBookNumbers() {
        let pages = NooraniQaidaCatalog.loadPagesFromBundle()
        XCTAssertEqual(pages.count, 53, "Noorani Qaida JSON must contain all 53 pages")
        XCTAssertEqual(pages.first?.pageNumber, 1)
        XCTAssertEqual(pages.last?.pageNumber, 53)
        XCTAssertEqual(pages.last?.bookPageNumber, 56, "PDF page 53 corresponds to printed top book page 56")
    }

    func testNooraniQaidaExercisesCoverBasicIntermediateAndHardTiers() {
        let basic = NooraniQaidaCatalog.exercises(for: .basic)
        let intermediate = NooraniQaidaCatalog.exercises(for: .intermediate)
        let hard = NooraniQaidaCatalog.exercises(for: .hard)

        XCTAssertGreaterThanOrEqual(basic.count, 10)
        XCTAssertGreaterThanOrEqual(intermediate.count, 10)
        XCTAssertGreaterThanOrEqual(hard.count, 10)
        XCTAssertEqual(NooraniQaidaCatalog.allExercises.count, 35)
    }

    func testQuranReciterCatalogHas280RecitersWithStableIds() {
        let reciters = QuranReaderView.catalogReciters
        XCTAssertEqual(reciters.count, 280)
        XCTAssertTrue(reciters.contains(where: { $0.id == "mishary_rashid_alafasy" }))
        XCTAssertTrue(reciters.contains(where: { $0.id == "islam_sobhi" }))
    }

    func testAzkarAndMasnoonDuasCatalogAndQuranicAudioMapping() {
        XCTAssertEqual(DailyDuaItem.realVoiceComingSoonMessage, "No audio available")
        let allDuas = DailyDuasCatalog.allDuas
        XCTAssertGreaterThanOrEqual(allDuas.count, 11)

        // Non-Quranic Hadith duas must have nil quranSurahAyah
        let sehriDua = allDuas.first(where: { $0.id == "dua_ramadan_sehri_niyyah" })
        let iftarDua = allDuas.first(where: { $0.id == "dua_ramadan_iftar" })
        XCTAssertNotNil(sehriDua)
        XCTAssertNotNil(iftarDua)
        XCTAssertNil(sehriDua?.quranSurahAyah)
        XCTAssertNil(iftarDua?.quranSurahAyah)

        // Authentic Quranic duas must map to their exact Surah:Ayah
        let ayatAlKursi = allDuas.first(where: { $0.id == "dua_ayat_al_kursi" })
        let rabbanaAtina = allDuas.first(where: { $0.id == "dua_rabbana_fid_dunya" })
        let rabbiZidniIlma = allDuas.first(where: { $0.id == "dua_increase_knowledge_ilm" })
        let safarVerse = allDuas.first(where: { $0.id == "dua_safar_travel" })

        XCTAssertEqual(ayatAlKursi?.quranSurah, 2)
        XCTAssertEqual(ayatAlKursi?.quranAyah, 255)
        XCTAssertEqual(rabbanaAtina?.quranSurah, 2)
        XCTAssertEqual(rabbanaAtina?.quranAyah, 201)
        XCTAssertEqual(rabbiZidniIlma?.quranSurah, 20)
        XCTAssertEqual(rabbiZidniIlma?.quranAyah, 114)
        XCTAssertEqual(safarVerse?.quranSurah, 43)
        XCTAssertEqual(safarVerse?.quranAyah, 13)
    }
}
