import AVFoundation
import SwiftUI

enum DuaCategory: String, CaseIterable, Identifiable {
    case all = "All Azkar"
    case morningEvening = "Morning & Evening"
    case afterSalah = "After Salah (Namaz)"
    case sleepWake = "Sleep, Wake & Dress"
    case homeMasjid = "Home, Masjid & Daily"
    case quranicRabbana = "Quranic & Prophetic"
    case specialOccasions = "Special Occasions & Ramadan"

    var id: String { rawValue }

    var arabicLabel: String {
        switch self {
        case .all: return "جميع الأذكار"
        case .morningEvening: return "أذكار الصباح والمساء"
        case .afterSalah: return "أذكار بعد الصلاة"
        case .sleepWake: return "أذكار النوم والاستيقاظ"
        case .homeMasjid: return "أذكار المنزل والمسجد"
        case .quranicRabbana: return "الأدعية القرآنية والنبوية"
        case .specialOccasions: return "أدعية رمضان والمناسبات"
        }
    }
}

struct DailyDuaItem: Identifiable, Equatable {
    static let realVoiceComingSoonMessage = "No audio available"

    let id: String
    let title: String
    let category: DuaCategory
    let occasionBadge: String
    let arabicText: String
    let transliteration: String
    let englishTranslation: String
    let urduTranslation: String
    let authenticReference: String
    let virtueAndTiming: String
    let recommendedCount: Int
    let quranSurah: Int?
    let quranAyah: Int?
    let searchKeywordsRomanUrduAndAliases: String
    let humanAudioUrl: String?

    var quranSurahAyah: (Int, Int)? {
        if let s = quranSurah, let a = quranAyah { return (s, a) }
        return nil
    }
}

final class DuaAudioPlayerCoordinator: ObservableObject {
    @Published var playingDuaId: String? = nil
    @Published var statusBannerMessage: String? = nil
    private var player: AVPlayer?

    func playOrToggle(dua: DailyDuaItem) {
        if playingDuaId == dua.id {
            player?.pause()
            playingDuaId = nil
            return
        }

        let resolvedUrlString: String?
        if let (surah, ayah) = dua.quranSurahAyah {
            let sPad = String(format: "%03d", surah)
            let aPad = String(format: "%03d", ayah)
            resolvedUrlString = "https://everyayah.com/data/Alafasy_128kbps/\(sPad)\(aPad).mp3"
        } else {
            resolvedUrlString = dua.humanAudioUrl
        }

        guard let urlStr = resolvedUrlString, let url = URL(string: urlStr) else {
            playingDuaId = nil
            statusBannerMessage = DailyDuaItem.realVoiceComingSoonMessage
            return
        }

        statusBannerMessage = nil
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)
        player = AVPlayer(url: url)
        player?.play()
        playingDuaId = dua.id
    }
}

enum DailyDuasCatalog {
    static let allDuas: [DailyDuaItem] = [
        DailyDuaItem(
            id: "dua_ayat_al_kursi",
            title: "Ayat al-Kursi (Verse of the Throne / آیت الکرسی)",
            category: .morningEvening,
            occasionBadge: "Morning, Evening, After Salah & Before Sleep",
            arabicText: "ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلْحَىُّ ٱلْقَيُّومُ ۚ لَا تَأْخُذُهُۥ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُۥ مَا فِى ٱلسَّمَٰوَٰتِ وَمَا فِى ٱلْأَرْضِ ۗ مَن ذَا ٱلَّذِى يَشْفَعُ عِندَهُۥٓ إِلَّا بِإِذْنِهِۦ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَىْءٍ مِّنْ عِلْمِهِۦٓ إِلَّا بِمَا شَآءَ ۚ وَسِعَ كُرْسِيُّهُ ٱلسَّمَٰوَٰتِ وَٱلْأَرْضَ ۖ وَلَا يَـُٔودُهُۥ حِفْظُهُمَا ۚ وَهُوَ ٱلْعَلِىُّ ٱلْعَظِيمُ",
            transliteration: "Allahu la ilaha illa Huwal-Hayyul-Qayyum, la ta'khudhuhu sinatun wa la nawm...",
            englishTranslation: "Allah — there is no deity except Him, the Ever-Living, the Sustainer of all existence. Neither drowsiness overtakes Him nor sleep...",
            urduTranslation: "اللہ کے سوا کوئی معبود نہیں، وہ زندہ ہے، سب کا تھامنے والا ہے، نہ اسے اونگھ آتی ہے اور نہ نیند...",
            authenticReference: "Surah Al-Baqarah 2:255 • Sahih al-Bukhari 2311",
            virtueAndTiming: "Recite after every obligatory prayer, morning, evening, and before sleeping for continuous divine protection.",
            recommendedCount: 1,
            quranSurah: 2,
            quranAyah: 255,
            searchKeywordsRomanUrduAndAliases: "ayatul kursi ayat ul kursi hifazat ki dua namaz ke baad ki dua",
            humanAudioUrl: "https://everyayah.com/data/Alafasy_128kbps/002255.mp3"
        ),
        DailyDuaItem(
            id: "dua_sayyidul_istighfar",
            title: "Sayyidul Istighfar (Chief Supplication for Forgiveness / سید الاستغفار)",
            category: .morningEvening,
            occasionBadge: "Morning & Evening Master Istighfar",
            arabicText: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
            transliteration: "Allahumma Anta Rabbi la ilaha illa Anta, khalaqtani wa ana 'abduka...",
            englishTranslation: "O Allah, You are my Lord; there is no deity worthy of worship except You. You created me and I am Your servant...",
            urduTranslation: "اے اللہ! تو ہی میرا رب ہے، تیرے سوا کوئی معبود نہیں، تو نے مجھے پیدا کیا اور میں تیرا بندہ ہوں...",
            authenticReference: "Sahih al-Bukhari 6306 • Hisn al-Muslim #79",
            virtueAndTiming: "Whoever recites this with conviction in the morning or evening and passes away enters Paradise.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "sayyidul istighfar maghfirat ki dua tauba ki dua bakhshish ki dua",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_tasbih_fatimah",
            title: "Tasbih-e-Fatimah After Every Salah (تسبیح فاطمہ)",
            category: .afterSalah,
            occasionBadge: "After Every Fard Salah & Before Sleep",
            arabicText: "سُبْحَانَ اللَّهِ (٣٣) • الْحَمْدُ لِلَّهِ (٣٣) • اللَّهُ أَكْبَرُ (٣٤)",
            transliteration: "SubhanAllah (33), Alhamdulillah (33), Allahu Akbar (34)",
            englishTranslation: "Glory be to Allah (33 times), All praise is due to Allah (33 times), Allah is the Greatest (34 times).",
            urduTranslation: "سبحان اللہ (33 بار)، الحمد للہ (33 بار)، اللہ اکبر (34 بار)۔",
            authenticReference: "Sahih Muslim 597 • Sahih al-Bukhari 5361",
            virtueAndTiming: "Sins are forgiven even if they are like the foam of the sea.",
            recommendedCount: 33,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "tasbih fatima namaz ke baad ki tasbeeh subhanallah alhamdulillah allahu akbar",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_before_sleeping_sone",
            title: "Dua Before Sleeping (Sone Ki Dua / سونے کی دعا)",
            category: .sleepWake,
            occasionBadge: "At Bedtime",
            arabicText: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
            transliteration: "Bismika Allahumma amutu wa ahya.",
            englishTranslation: "In Your name, O Allah, I die and I live.",
            urduTranslation: "اے اللہ! میں تیرے ہی نام کے ساتھ مرتا (سوتا) ہوں اور جیتا (جاگتا) ہوں۔",
            authenticReference: "Sahih al-Bukhari 6324",
            virtueAndTiming: "Recite when placing your head on the pillow to sleep.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "sone ki dua neend ki dua sleeping dua",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_before_eating_khana",
            title: "Dua Before Eating (Khana Khane Ki Dua / کھانا کھانے سے پہلے کی دعا)",
            category: .homeMasjid,
            occasionBadge: "Before Meals",
            arabicText: "بِسْمِ اللَّهِ وَعَلَى بَرَكَةِ اللَّهِ",
            transliteration: "Bismillahi wa 'ala barakatillah.",
            englishTranslation: "In the name of Allah and upon the blessings of Allah.",
            urduTranslation: "اللہ کے نام سے اور اللہ کی برکت پر (کھانا شروع کرتا ہوں)۔",
            authenticReference: "Sunan Abi Dawud 3767 • Al-Mustadrak al-Hakim 7076",
            virtueAndTiming: "Recite before starting any meal or drink.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "khana khane ki dua before eating meal bismillah",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_drinking_water_pani",
            title: "Dua After Drinking Water (Pani Peene Ke Baad Ki Dua / پانی پینے کے بعد کی دعا)",
            category: .homeMasjid,
            occasionBadge: "After Drinking Water",
            arabicText: "الْحَمْدُ لِلَّهِ الَّذِي سَقَانَا عَذْبًا فُرَاتًا بِرَحْمَتِهِ وَلَمْ يَجْعَلْهُ مِلْحًا أُجَاجًا بِذُنُوبِنَا",
            transliteration: "Alhamdulillahi-lladhi saqana 'adhban furatan birahmatihi wa lam yaj'alhu milhan ujajan bidhunubina.",
            englishTranslation: "All praise is to Allah Who gave us sweet, pleasant water to drink by His mercy and did not make it salty and bitter due to our sins.",
            urduTranslation: "سب تعریف اللہ کے لیے ہے جس نے ہمیں اپنی رحمت سے میٹھا اور خوشگوار پانی پلایا اور ہمارے گناہوں کی وجہ سے اسے کھارا اور کڑوا نہیں بنایا۔",
            authenticReference: "Hilyat al-Awliya • Shu'ab al-Iman al-Bayhaqi",
            virtueAndTiming: "Drink water in three breaths sitting down, starting with Bismillah and ending with Alhamdulillah.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "pani peene ki dua drinking water dua",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_rabbana_fid_dunya",
            title: "Rabbana Atina Fid-Dunya Hasanah (ربنا آتنا في الدنيا حسنة)",
            category: .quranicRabbana,
            occasionBadge: "Most Frequent Prophetic Quranic Dua",
            arabicText: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            transliteration: "Rabbana atina fid-dunya hasanatan wa fil-akhirati hasanatan wa qina 'adhaban-nar.",
            englishTranslation: "Our Lord, give us in this world [that which is] good and in the Hereafter [that which is] good and protect us from the punishment of the Fire.",
            urduTranslation: "اے ہمارے رب! ہمیں دنیا میں بھی بھلائی عطا فرما اور آخرت میں بھی بھلائی عطا فرما اور ہمیں آگ کے عذاب سے بچا۔",
            authenticReference: "Surah Al-Baqarah 2:201 • Sahih al-Bukhari 4522",
            virtueAndTiming: "The most frequent supplication of the Prophet (ﷺ).",
            recommendedCount: 3,
            quranSurah: 2,
            quranAyah: 201,
            searchKeywordsRomanUrduAndAliases: "rabbana atina duniya aur akhirat ki bhalai ki dua",
            humanAudioUrl: "https://everyayah.com/data/Alafasy_128kbps/002201.mp3"
        ),
        DailyDuaItem(
            id: "dua_increase_knowledge_ilm",
            title: "Dua for Increasing Knowledge (Ilm Mein Izafe Ki Dua / علم میں اضافے کی دعا)",
            category: .quranicRabbana,
            occasionBadge: "Seeking Beneficial Knowledge",
            arabicText: "رَّبِّ زِدْنِي عِلْمًا",
            transliteration: "Rabbi zidni 'ilma.",
            englishTranslation: "My Lord, increase me in knowledge.",
            urduTranslation: "اے میرے رب! میرے علم میں اضافہ فرما۔",
            authenticReference: "Surah Taha 20:114",
            virtueAndTiming: "Recite before studying Quran, Hadith, or beneficial knowledge.",
            recommendedCount: 3,
            quranSurah: 20,
            quranAyah: 114,
            searchKeywordsRomanUrduAndAliases: "rabbi zidni ilma ilm ki dua padhai ki dua exam ki dua",
            humanAudioUrl: "https://everyayah.com/data/Alafasy_128kbps/020114.mp3"
        ),
        DailyDuaItem(
            id: "dua_safar_travel",
            title: "Dua for Travel & Riding (Safar Ki Dua / سفر کی دعا)",
            category: .specialOccasions,
            occasionBadge: "Safar (Journey & Riding)",
            arabicText: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنْقَلِبُونَ",
            transliteration: "Subhanalladhi sakhkhara lana hadha wa ma kunna lahu muqrinin, wa inna ila Rabbina lamunqalibun.",
            englishTranslation: "Exalted is He who has subjected this to us, and we could not have [otherwise] subdued it. And indeed we, to our Lord, will [surely] return.",
            urduTranslation: "پاک ہے وہ ذات جس نے اس سواری کو ہمارے بس میں کر دیا حالانکہ ہم اسے قابو میں لانے والے نہ تھے، اور بے شک ہمیں اپنے رب ہی کی طرف لوٹ کر جانا ہے۔",
            authenticReference: "Surah Az-Zukhruf 43:13-14 • Sahih Muslim 1342",
            virtueAndTiming: "Recite when boarding any vehicle or beginning a journey.",
            recommendedCount: 1,
            quranSurah: 43,
            quranAyah: 13,
            searchKeywordsRomanUrduAndAliases: "safar ki dua gari mein baithne ki dua travel dua",
            humanAudioUrl: "https://everyayah.com/data/Alafasy_128kbps/043013.mp3"
        ),
        DailyDuaItem(
            id: "dua_ramadan_sehri_niyyah",
            title: "Dua for Suhoor / Fasting Intention (Sehri Ki Dua / سحری و روزے کی نیت)",
            category: .specialOccasions,
            occasionBadge: "Ramadan Suhoor (Sehri)",
            arabicText: "وَبِصَوْمِ غَدٍ نَّوَيْتُ مِنْ شَهْرِ رَمَضَانَ",
            transliteration: "Wa bisawmi ghadin nawaytu min shahri Ramadan.",
            englishTranslation: "I intend to keep the fast for tomorrow in the month of Ramadan.",
            urduTranslation: "اور میں نے ماہِ رمضان کے کل کے روزے کی نیت کی۔",
            authenticReference: "Sunan Abi Dawud 2454 (Intention in heart is Fard; verbalizing aids focus)",
            virtueAndTiming: "Make the firm intention at Suhoor before Fajr begins.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "sehri ki dua roze ki niyat suhoor dua ramzan",
            humanAudioUrl: nil
        ),
        DailyDuaItem(
            id: "dua_ramadan_iftar",
            title: "Authentic Dua at Iftar (Iftari Ki Dua / افطاری کی مسنون دعا)",
            category: .specialOccasions,
            occasionBadge: "Ramadan Breaking Fast (Iftar)",
            arabicText: "ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ، وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ",
            transliteration: "Zahaba al-zama'u wabtallatil-'urooqu, wa thabatal-ajru in sha'Allah.",
            englishTranslation: "The thirst has gone, the veins are moistened, and the reward is confirmed, if Allah wills.",
            urduTranslation: "پیاس چلی گئی، رگیں تر ہو گئیں اور ان شاء اللہ اجر ثابت ہو گیا۔",
            authenticReference: "Sunan Abi Dawud 2357 (Hasan)",
            virtueAndTiming: "Recite upon breaking the fast at Maghrib with dates or water.",
            recommendedCount: 1,
            quranSurah: nil,
            quranAyah: nil,
            searchKeywordsRomanUrduAndAliases: "iftar ki dua iftari ki dua roza kholne ki dua",
            humanAudioUrl: nil
        )
    ]
}

struct DuasAndSettingsView: View {
    @EnvironmentObject private var persistence: PersistenceController
    @StateObject private var audioCoordinator = DuaAudioPlayerCoordinator()
    @AppStorage("app_color_scheme") private var appColorScheme: String = "system"
    @AppStorage("preferred_reciter_id") private var preferredReciterId: String = "mishary_rashid_alafasy"
    @AppStorage("last_read_noorani_qaida_page") private var lastQaidaPage: Int = 1

    @State private var selectedCategory: DuaCategory = .all
    @State private var searchQuery: String = ""
    @State private var tasbihCounts: [String: Int] = [:]
    @State private var showSettingsSheet: Bool = false

    private var filteredDuas: [DailyDuaItem] {
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return DailyDuasCatalog.allDuas.filter { dua in
            let matchesCat = selectedCategory == .all || dua.category == selectedCategory
            let matchesSearch = q.isEmpty
                || dua.title.lowercased().contains(q)
                || dua.arabicText.contains(q)
                || dua.transliteration.lowercased().contains(q)
                || dua.englishTranslation.lowercased().contains(q)
                || dua.urduTranslation.contains(q)
                || dua.searchKeywordsRomanUrduAndAliases.lowercased().contains(q)
                || dua.authenticReference.lowercased().contains(q)
            return matchesCat && matchesSearch
        }
    }

    var body: some View {
        VStack(spacing: 10) {
            // Search Bar (supports Arabic, English, Urdu, and Roman Urdu like "sehri ki dua", "sone ki dua")
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Search Azkar & Duas (Arabic, English, Urdu, Roman Urdu)...", text: $searchQuery)
                if !searchQuery.isEmpty {
                    Button {
                        searchQuery = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding(10)
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)

            // Horizontal Category Filter Bar
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(DuaCategory.allCases) { category in
                        Button {
                            selectedCategory = category
                        } label: {
                            VStack(spacing: 2) {
                                Text(category.rawValue)
                                    .font(.system(size: 12, weight: .bold))
                                Text(category.arabicLabel)
                                    .font(IslamicTheme.arabicFont(size: 12))
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selectedCategory == category ? IslamicTheme.emeraldPrimary : Color(UIColor.secondarySystemBackground))
                            .foregroundColor(selectedCategory == category ? .white : .primary)
                            .cornerRadius(10)
                        }
                    }
                }
                .padding(.horizontal)
            }

            if let banner = audioCoordinator.statusBannerMessage {
                HStack {
                    Image(systemName: "info.circle.fill")
                    Text(banner)
                        .font(.caption.bold())
                    Spacer()
                    Button("Dismiss") {
                        audioCoordinator.statusBannerMessage = nil
                    }
                    .font(.caption)
                }
                .padding(10)
                .background(IslamicTheme.goldPrimary.opacity(0.25))
                .cornerRadius(10)
                .padding(.horizontal)
            }

            ScrollView {
                LazyVStack(spacing: 14) {
                    ForEach(filteredDuas) { dua in
                        duaCard(for: dua)
                    }
                }
                .padding()
            }
        }
        .navigationTitle("Azkar & Duas • الأذكار")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showSettingsSheet = true
                } label: {
                    Image(systemName: "gearshape.fill")
                }
                .accessibilityLabel("App Appearance & Sync Settings")
            }
        }
        .sheet(isPresented: $showSettingsSheet) {
            settingsSheetView
        }
    }

    private func duaCard(for dua: DailyDuaItem) -> some View {
        let currentCount = tasbihCounts[dua.id, default: 0]
        let isPlaying = audioCoordinator.playingDuaId == dua.id

        return VStack(alignment: .trailing, spacing: 10) {
            HStack {
                Text(dua.occasionBadge)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(IslamicTheme.emeraldPrimary.opacity(0.14))
                    .foregroundColor(IslamicTheme.emeraldPrimary)
                    .cornerRadius(6)

                Spacer()

                if let (s, a) = dua.quranSurahAyah {
                    Text("Quran \(s):\(a)")
                        .font(.caption2.bold())
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(IslamicTheme.goldPrimary.opacity(0.3))
                        .cornerRadius(6)
                }
            }

            Text(dua.title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text(dua.arabicText)
                .font(IslamicTheme.arabicFont(size: 25))
                .foregroundColor(IslamicTheme.emeraldDeep)
                .forceArabicRTL()
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.vertical, 4)

            Text(dua.transliteration)
                .font(.system(size: 13, weight: .medium).italic())
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text(dua.urduTranslation)
                .font(IslamicTheme.arabicFont(size: 18))
                .foregroundColor(IslamicTheme.emeraldPrimary)
                .forceArabicRTL()
                .frame(maxWidth: .infinity, alignment: .trailing)

            Text(dua.englishTranslation)
                .font(.system(size: 14))
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)

            Divider()

            HStack(spacing: 10) {
                // Audio button (streams authentic Quranic verse audio or shows "No audio available")
                Button {
                    audioCoordinator.playOrToggle(dua: dua)
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: isPlaying ? "pause.circle.fill" : "speaker.wave.2.fill")
                        Text(dua.quranSurahAyah != nil ? (isPlaying ? "Pause" : "Listen") : "Audio")
                            .font(.caption.bold())
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(IslamicTheme.emeraldPrimary)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }

                // Interactive Tasbih Counter
                Button {
                    tasbihCounts[dua.id] = currentCount + 1
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "repeat.circle.fill")
                        Text("Tasbih: \(currentCount)/\(dua.recommendedCount)")
                            .font(.caption.bold())
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(currentCount >= dua.recommendedCount ? Color.green.opacity(0.2) : IslamicTheme.goldPrimary.opacity(0.25))
                    .foregroundColor(IslamicTheme.emeraldDeep)
                    .cornerRadius(8)
                }

                Spacer()

                Text(dua.authenticReference)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
        }
        .islamicIlluminatedCard(cornerRadius: 18, shadowRadius: 5, showCornerMedallions: false)
    }

    private var settingsSheetView: some View {
        NavigationView {
            Form {
                Section("Appearance & Sync State") {
                    Picker("Theme Mode", selection: $appColorScheme) {
                        Text("System").tag("system")
                        Text("Light").tag("light")
                        Text("Dark").tag("dark")
                    }
                    HStack {
                        Text("Saved Reciter ID")
                        Spacer()
                        Text(preferredReciterId)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Last Noorani Qaida Page")
                        Spacer()
                        Text("Page \(lastQaidaPage) of 53")
                            .font(.caption.bold())
                            .foregroundColor(IslamicTheme.emeraldPrimary)
                    }
                }

                Section("Platform Parity Info") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.2 (Build 8)")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Primary Upstream Repo")
                        Spacer()
                        Text("Bayan-ul-huda-quran-o-hadees")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("App Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showSettingsSheet = false }
                }
            }
        }
    }
}
